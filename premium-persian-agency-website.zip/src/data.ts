import avatar1 from "./assets/avatar1.jpg";
import avatar2 from "./assets/avatar2.jpg";
import avatar3 from "./assets/avatar3.jpg";

export const NAV_LINKS = [
  { label: "خانه", href: "#home", id: "home" },
  { label: "نمونه کارها", href: "#projects", id: "projects" },
  { label: "خدمات", href: "#services", id: "services" },
  { label: "فروشگاه", href: "#pricing", id: "pricing" },
  { label: "درباره من", href: "#testimonials", id: "testimonials" },
  { label: "تماس", href: "#contact", id: "contact" },
];

export const SERVICE_OPTIONS = [
  "طراحی سایت شرکتی",
  "فروشگاه آنلاین",
  "برندینگ و هویت بصری",
  "طراحی لندینگ",
  "طراحی رابط و تجربه کاربری",
  "بازاریابی دیجیتال",
];

// Arrays are listed in visual right-to-left order (first = rightmost on desktop).
export const FEATURES = [
  { icon: "pencil", title: "طراحی خلاقانه", text: "متناسب با هویت برند شما" },
  { icon: "search", title: "بهینه برای گوگل", text: "سئو و سرعت بالا" },
  { icon: "headphones", title: "پشتیبانی دائمی", text: "همیشه در کنار شما" },
  { icon: "database", title: "قیمت منصفانه", text: "کیفیت بالا، هزینه منطقی" },
] as const;

export const SERVICES = [
  {
    icon: "megaphone",
    title: "طراحی لندینگ",
    text: "صفحات اختصاصی\nبرای کمپین‌ها",
    option: "طراحی لندینگ",
  },
  {
    icon: "monitor",
    title: "طراحی سایت",
    text: "سایت‌های شرکتی، شخصی\nو فروشگاهی",
    option: "طراحی سایت شرکتی",
  },
  {
    icon: "palette",
    title: "برندینگ",
    text: "طراحی هویت بصری و\nشخصیت برند",
    option: "برندینگ و هویت بصری",
  },
  {
    icon: "bag",
    title: "فروشگاه آنلاین",
    text: "فروش محصولات و خدمات\nبه صورت حرفه‌ای",
    option: "فروشگاه آنلاین",
  },
] as const;

export const PLANS = [
  {
    id: "basic",
    title: "پایه",
    subtitle: "سایت تک‌صفحه‌ای",
    price: 5000000,
    features: ["طراحی واکنش‌گرا", "بهینه‌سازی پایه"],
    featured: false,
    option: "طراحی سایت شرکتی",
  },
  {
    id: "pro",
    title: "حرفه‌ای",
    subtitle: "سایت چندصفحه‌ای",
    price: 9500000,
    features: ["طراحی اختصاصی", "پنل مدیریت"],
    featured: true,
    option: "طراحی سایت شرکتی",
  },
  {
    id: "advanced",
    title: "پیشرفته",
    subtitle: "فروشگاه آنلاین",
    price: 15000000,
    features: ["درگاه پرداخت", "پشتیبانی ویژه"],
    featured: false,
    option: "فروشگاه آنلاین",
  },
] as const;

export const TESTIMONIALS = [
  {
    name: "مهسا کریمی",
    role: "مدیر کسب‌وکار",
    text: "سایت ما ظاهر حرفه‌ای‌تری پیدا کرد\nو تجربه کاربران بهتر شد.",
    avatar: avatar3,
  },
  {
    name: "علی رضایی",
    role: "مدیر برند",
    text: "فرایند طراحی بسیار منظم بود.\nنتیجه دقیقاً مطابق انتظار ما بود.",
    avatar: avatar2,
  },
  {
    name: "سارا محمدی",
    role: "صاحب فروشگاه آنلاین",
    text: "طراحی سایت فوق‌العاده بود.\nهم سرعت سایت بهتر شد و هم تجربه کاربران.",
    avatar: avatar1,
  },
] as const;

export const PROJECTS = [
  { title: "فروشگاه هدفون", category: "طراحی فروشگاه آنلاین", filter: "none" },
  { title: "وب‌سایت شرکتی", category: "طراحی سایت شرکتی", filter: "hue-rotate(-28deg) saturate(1.1)" },
  { title: "هویت بصری و لندینگ", category: "برندینگ و لندینگ", filter: "hue-rotate(32deg) saturate(1.05)" },
];

export const SOCIALS = [
  { name: "اینستاگرام", href: "https://instagram.com/", icon: "instagram" },
  { name: "تلگرام", href: "https://t.me/", icon: "telegram" },
  { name: "لینکدین", href: "https://linkedin.com/", icon: "linkedin" },
  { name: "یوتیوب", href: "https://youtube.com/", icon: "youtube" },
] as const;

export const toFa = (n: number) =>
  String(n)
    .replace(/\B(?=(\d{3})+(?!\d))/g, ",")
    .replace(/\d/g, (d) => "۰۱۲۳۴۵۶۷۸۹"[Number(d)]);
