import { useCallback, useState } from "react";
import { Header } from "./components/Header";
import { Hero } from "./components/Hero";
import { Features } from "./components/Features";
import { Projects } from "./components/Projects";
import { Services } from "./components/Services";
import { Pricing } from "./components/Pricing";
import { Testimonials } from "./components/Testimonials";
import { CtaBanner } from "./components/CtaBanner";
import { Footer } from "./components/Footer";
import { OrderModal } from "./components/OrderModal";

export default function App() {
  const [order, setOrder] = useState<{ open: boolean; service?: string; plan?: string }>({ open: false });

  const openOrder = useCallback((service?: string, plan?: string) => setOrder({ open: true, service, plan }), []);
  const closeOrder = useCallback(() => setOrder((o) => ({ ...o, open: false })), []);

  return (
    <div dir="rtl" className="relative isolate min-h-screen overflow-x-clip bg-ink font-sans text-txt">
      <div className="ambient" aria-hidden="true">
        <div className="absolute -right-20 top-[6%] h-80 w-80 animate-drift rounded-full bg-brand/10 blur-3xl" />
        <div className="absolute -left-24 top-[48%] h-96 w-96 animate-drift rounded-full bg-glow/10 blur-3xl [animation-delay:-6s]" />
      </div>
      <div className="relative z-10">
        <Header onOrder={() => openOrder()} />
        <main>
          <Hero onOrder={() => openOrder()} />
          <Features />
          <Projects />
          <Services onOrder={openOrder} />
          <Pricing onOrder={openOrder} />
          <Testimonials />
          <CtaBanner onOrder={() => openOrder()} />
        </main>
        <Footer />
      </div>
      <OrderModal open={order.open} onClose={closeOrder} initialService={order.service} initialPlan={order.plan} />
    </div>
  );
}
