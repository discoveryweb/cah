import { Star } from "lucide-react";
import { TESTIMONIALS } from "../data";
import { Reveal, SectionBadge } from "./ui";

export function TestimonialCard({ t }: { t: (typeof TESTIMONIALS)[number] }) {
  return (
    <figure className="glass-card flex h-full flex-col rounded-2xl p-5 transition-all duration-300 hover:-translate-y-1 hover:border-violet/60">
      <figcaption className="flex items-center gap-3">
        <img
          src={t.avatar}
          alt={`تصویر ${t.name}`}
          width={48}
          height={48}
          loading="lazy"
          className="h-12 w-12 rounded-full object-cover ring-2 ring-violet/60"
        />
        <div>
          <p className="text-sm font-bold text-txt">{t.name}</p>
          <p className="text-xs text-muted">{t.role}</p>
        </div>
      </figcaption>
      <blockquote className="mt-4 whitespace-pre-line text-[13px] leading-[1.95] text-txt-2">«{t.text}»</blockquote>
      <div className="mt-4 flex gap-1 self-end pt-1" role="img" aria-label="امتیاز ۵ از ۵">
        {Array.from({ length: 5 }).map((_, i) => (
          <Star key={i} className="h-3.5 w-3.5 fill-violet text-violet" aria-hidden="true" />
        ))}
      </div>
    </figure>
  );
}

export function Testimonials() {
  return (
    <section id="testimonials" className="relative py-8 lg:py-10">
      <div className="mx-auto max-w-[1180px] px-5 sm:px-8">
        <Reveal className="flex flex-col items-center text-center">
          <SectionBadge>نظرات مشتریان</SectionBadge>
          <h2 className="mt-3 text-[1.5rem] font-extrabold text-txt sm:text-[1.8rem]">آنچه مشتریان می‌گویند</h2>
        </Reveal>
        <ul className="mt-7 grid grid-cols-1 gap-4 md:grid-cols-3">
          {TESTIMONIALS.map((t, i) => (
            <li key={t.name}>
              <Reveal delay={i * 90} className="h-full">
                <TestimonialCard t={t} />
              </Reveal>
            </li>
          ))}
        </ul>
      </div>
    </section>
  );
}
