import { LogoMark, SocialIcon } from "./ui";
import { SOCIALS } from "../data";

export function Footer() {
  return (
    <footer className="relative pb-8 pt-4">
      <div className="mx-auto flex max-w-[1180px] flex-col items-center gap-5 px-5 sm:px-8 md:flex-row md:justify-between">
        <a href="#home" className="flex items-center gap-2 md:order-1" aria-label="وبساز — بازگشت به بالای صفحه">
          <LogoMark className="h-9 w-9 drop-shadow-[0_0_12px_rgba(139,77,255,0.6)]" />
        </a>
        <p className="text-center text-xs text-txt-2 md:order-2">وبساز © طراحی سایت، فروشگاه و برندینگ</p>
        <ul className="flex items-center gap-2 md:order-3" aria-label="شبکه‌های اجتماعی">
          {SOCIALS.map((s) => (
            <li key={s.name}>
              <a
                href={s.href}
                target="_blank"
                rel="noopener noreferrer"
                aria-label={s.name}
                className="flex h-10 w-10 items-center justify-center rounded-full text-txt-2 transition-all hover:bg-brand/20 hover:text-lav hover:shadow-[0_0_20px_-4px_rgba(139,77,255,0.8)]"
              >
                <SocialIcon name={s.icon} />
              </a>
            </li>
          ))}
        </ul>
      </div>
    </footer>
  );
}
