import { useEffect, useRef, type ReactNode, type CSSProperties } from "react";
import { ArrowUpLeft } from "lucide-react";
import { cn } from "../utils/cn";

/** Custom two-slanted-shapes logo mark */
export function LogoMark({ className = "h-9 w-9" }: { className?: string }) {
  return (
    <svg viewBox="0 0 48 48" className={className} aria-hidden="true">
      <defs>
        <linearGradient id="lm1" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0" stopColor="#C5A2FF" />
          <stop offset="1" stopColor="#7A45FF" />
        </linearGradient>
        <linearGradient id="lm2" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0" stopColor="#8B4DFF" />
          <stop offset="1" stopColor="#4B2BE0" />
        </linearGradient>
      </defs>
      <path d="M22 4.5c1.2-1.6 3.4-1.6 4.6 0l6.4 8.3c.9 1.2.9 2.8 0 4L16.8 38c-1 1.3-3 1.4-4.2.2L5 30.6c-1-1-1.2-2.6-.4-3.8L22 4.5Z" fill="url(#lm2)" />
      <path d="M33.5 12.5c1.2-1.6 3.4-1.6 4.6 0l5.4 7c.9 1.2.9 2.8 0 4L28.6 43c-1 1.3-3 1.4-4.2.2l-1.6-1.5 15-19.4c.9-1.2.9-2.8 0-4l-4.3-5.8Z" fill="url(#lm1)" />
    </svg>
  );
}

export function Reveal({
  children,
  className,
  delay = 0,
  as: Tag = "div",
}: {
  children: ReactNode;
  className?: string;
  delay?: number;
  as?: "div" | "section" | "li" | "article";
}) {
  const ref = useRef<HTMLElement | null>(null);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    if (typeof IntersectionObserver === "undefined") {
      el.classList.add("is-visible");
      return;
    }
    const io = new IntersectionObserver(
      (entries) => {
        entries.forEach((e) => {
          if (e.isIntersecting) {
            e.target.classList.add("is-visible");
            io.unobserve(e.target);
          }
        });
      },
      { threshold: 0.08, rootMargin: "0px 0px -4% 0px" }
    );
    io.observe(el);
    // safety net so content never stays hidden
    const t = window.setTimeout(() => el.classList.add("is-visible"), 6000);
    return () => {
      io.disconnect();
      window.clearTimeout(t);
    };
  }, []);
  const style = { "--d": `${delay}ms` } as CSSProperties;
  const Comp = Tag as "div";
  return (
    <Comp ref={ref as React.RefObject<HTMLDivElement>} className={cn("reveal", className)} style={style}>
      {children}
    </Comp>
  );
}

export function SectionBadge({ children, className }: { children: ReactNode; className?: string }) {
  return (
    <span
      className={cn(
        "inline-flex items-center rounded-full border border-brand/70 bg-brand/10 px-4 py-1 text-xs font-medium text-lav",
        className
      )}
    >
      {children}
    </span>
  );
}

type BtnProps = {
  children: ReactNode;
  variant?: "primary" | "outline";
  href?: string;
  onClick?: () => void;
  type?: "button" | "submit";
  className?: string;
  arrow?: boolean;
  disabled?: boolean;
  ariaLabel?: string;
};

export function Button({
  children,
  variant = "primary",
  href,
  onClick,
  type = "button",
  className,
  arrow = true,
  disabled,
  ariaLabel,
}: BtnProps) {
  const cls = cn(
    "group inline-flex min-h-11 items-center justify-center gap-2 rounded-full px-6 text-sm font-semibold transition-all duration-300 disabled:cursor-not-allowed disabled:opacity-60",
    variant === "primary"
      ? "btn-grad text-white hover:-translate-y-0.5"
      : "border border-brand/80 bg-ink-2/40 text-txt hover:-translate-y-0.5 hover:border-lav hover:bg-brand/15 hover:shadow-[0_0_28px_-6px_rgba(139,77,255,0.7)]",
    className
  );
  const content = (
    <>
      {arrow && (
        <ArrowUpLeft
          className="h-4 w-4 transition-transform duration-300 group-hover:-translate-x-0.5 group-hover:-translate-y-0.5"
          aria-hidden="true"
        />
      )}
      <span>{children}</span>
    </>
  );
  if (href) {
    return (
      <a href={href} onClick={onClick} className={cls} aria-label={ariaLabel}>
        {content}
      </a>
    );
  }
  return (
    <button type={type} onClick={onClick} className={cls} disabled={disabled} aria-label={ariaLabel}>
      {content}
    </button>
  );
}

export function SocialIcon({ name, className = "h-[18px] w-[18px]" }: { name: string; className?: string }) {
  const p = { viewBox: "0 0 24 24", className, fill: "none", stroke: "currentColor", strokeWidth: 1.8, strokeLinecap: "round" as const, strokeLinejoin: "round" as const, "aria-hidden": true };
  switch (name) {
    case "instagram":
      return (
        <svg {...p}>
          <rect x="3" y="3" width="18" height="18" rx="5" />
          <circle cx="12" cy="12" r="4" />
          <circle cx="17.5" cy="6.5" r="1" fill="currentColor" stroke="none" />
        </svg>
      );
    case "telegram":
      return (
        <svg {...p}>
          <path d="M21.5 3.5 2.8 10.7c-.8.3-.8 1.4 0 1.7l4.7 1.5 1.8 5.6c.2.7 1.1.9 1.6.4l2.6-2.5 4.8 3.5c.6.4 1.3.1 1.5-.6l3.2-15.2c.2-.8-.5-1.4-1.5-1.1Z" />
          <path d="m7.5 13.9 10.2-6.4-7.9 8.4" />
        </svg>
      );
    case "linkedin":
      return (
        <svg {...p}>
          <path d="M7 10v7M7 6.8v.1M11 17v-7m0 3.2c0-1.8 1.3-3.2 3-3.2s3 1.2 3 3.2V17" />
          <rect x="3" y="3" width="18" height="18" rx="4" />
        </svg>
      );
    default:
      return (
        <svg {...p}>
          <rect x="2.5" y="5.5" width="19" height="13" rx="4" />
          <path d="m10.2 9.6 4.3 2.4-4.3 2.4Z" fill="currentColor" />
        </svg>
      );
  }
}
