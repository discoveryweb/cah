import { Database, Headphones, PencilLine, Search } from "lucide-react";
import { FEATURES } from "../data";
import { Reveal } from "./ui";

const ICONS = { pencil: PencilLine, search: Search, headphones: Headphones, database: Database };

export function FeatureItem({ icon, title, text }: { icon: keyof typeof ICONS; title: string; text: string }) {
  const Icon = ICONS[icon];
  return (
    <div className="flex flex-col items-center text-center">
      <span className="icon-orb flex h-[60px] w-[60px] items-center justify-center rounded-full sm:h-[66px] sm:w-[66px]">
        <Icon className="h-6 w-6 text-white" strokeWidth={1.7} aria-hidden="true" />
      </span>
      <h3 className="mt-4 text-[17px] font-bold text-txt">{title}</h3>
      <p className="mt-1 text-[13px] text-muted">{text}</p>
    </div>
  );
}

export function Features() {
  return (
    <section aria-label="مزایای همکاری" className="relative py-8 lg:py-10">
      <div className="mx-auto max-w-[1180px] px-5 sm:px-8">
        <ul className="grid grid-cols-2 gap-x-4 gap-y-9 lg:grid-cols-4">
          {FEATURES.map((f, i) => (
            <li key={f.title}>
              <Reveal delay={i * 80}>
                <FeatureItem {...f} />
              </Reveal>
            </li>
          ))}
        </ul>
      </div>
    </section>
  );
}
