import { ArrowLeft, Megaphone, Monitor, Palette, ShoppingBag } from "lucide-react";
import { SERVICES } from "../data";
import { Reveal, SectionBadge } from "./ui";

const ICONS = { megaphone: Megaphone, monitor: Monitor, palette: Palette, bag: ShoppingBag };

export function ServiceCard({
  icon,
  title,
  text,
  onSelect,
}: {
  icon: keyof typeof ICONS;
  title: string;
  text: string;
  onSelect: () => void;
}) {
  const Icon = ICONS[icon];
  return (
    <article className="glass-card group relative flex h-full flex-col items-center rounded-2xl px-5 pb-5 pt-6 text-center transition-all duration-300 hover:-translate-y-1.5 hover:border-violet/80 hover:shadow-[0_24px_50px_-22px_rgba(113,60,255,0.75)]">
      <span className="icon-orb flex h-[52px] w-[52px] items-center justify-center rounded-full">
        <Icon className="h-6 w-6 text-white" strokeWidth={1.6} aria-hidden="true" />
      </span>
      <h3 className="mt-4 text-[17px] font-bold text-txt">{title}</h3>
      <p className="mt-2 whitespace-pre-line text-[13px] leading-[1.9] text-muted">{text}</p>
      <button
        type="button"
        onClick={onSelect}
        aria-label={`سفارش ${title}`}
        className="mt-auto flex h-8 w-8 items-center justify-center rounded-full bg-brand text-white shadow-[0_6px_18px_-6px_rgba(113,60,255,0.9)] transition-all duration-300 after:absolute after:inset-0 after:rounded-2xl group-hover:bg-violet"
        style={{ marginTop: "1.1rem" }}
      >
        <ArrowLeft className="h-4 w-4 transition-transform duration-300 group-hover:-translate-x-1" aria-hidden="true" />
      </button>
    </article>
  );
}

export function Services({ onOrder }: { onOrder: (service?: string) => void }) {
  return (
    <section id="services" className="relative py-8 lg:py-12">
      <div className="mx-auto max-w-[1180px] px-5 sm:px-8">
        <Reveal className="flex flex-col items-center text-center">
          <SectionBadge>خدمات</SectionBadge>
          <h2 className="mt-4 text-[1.55rem] font-extrabold leading-snug text-txt sm:text-[2rem]">هر آنچه برای حضور آنلاین نیاز دارید</h2>
        </Reveal>
        <ul className="mt-8 grid grid-cols-1 gap-4 min-[480px]:grid-cols-2 lg:grid-cols-4">
          {SERVICES.map((s, i) => (
            <li key={s.title}>
              <Reveal delay={i * 80} className="h-full">
                <ServiceCard icon={s.icon} title={s.title} text={s.text} onSelect={() => onOrder(s.option)} />
              </Reveal>
            </li>
          ))}
        </ul>
      </div>
    </section>
  );
}
