import { useEffect, useState } from "react";
import { ChevronDown } from "lucide-react";
import projectsImg from "../assets/projects.jpg";
import { PROJECTS } from "../data";
import { Reveal, SectionBadge } from "./ui";
import { cn } from "../utils/cn";

export function Projects() {
  const [index, setIndex] = useState(0);
  const [paused, setPaused] = useState(false);
  const [showAll, setShowAll] = useState(false);

  useEffect(() => {
    if (paused || window.matchMedia("(prefers-reduced-motion: reduce)").matches) return;
    const t = window.setInterval(() => setIndex((i) => (i + 1) % PROJECTS.length), 6000);
    return () => window.clearInterval(t);
  }, [paused]);

  const project = PROJECTS[index];

  return (
    <section id="projects" className="relative py-8 lg:py-12">
      <div className="mx-auto grid max-w-[1180px] items-center gap-8 px-5 sm:px-8 lg:grid-cols-[0.8fr_1.2fr] lg:gap-6">
        <Reveal className="flex flex-col items-start lg:ps-2">
          <SectionBadge>نمونه کارها</SectionBadge>
          <h2 className="mt-5 text-[1.9rem] font-extrabold leading-snug text-txt sm:text-[2.1rem]">برخی از پروژه‌های من</h2>
          <p className="mt-4 max-w-sm text-sm leading-[2] text-txt-2">
            طراحی سایت‌های شرکتی، فروشگاهی و برندینگ
            <br />
            با تمرکز بر زیبایی و عملکرد.
          </p>
          <button
            type="button"
            onClick={() => setShowAll((v) => !v)}
            aria-expanded={showAll}
            aria-controls="all-projects"
            className="group mt-7 inline-flex min-h-12 items-center justify-center gap-2 rounded-full border border-brand/80 bg-ink-2/40 px-8 text-sm font-semibold text-txt transition-all duration-300 hover:-translate-y-0.5 hover:border-lav hover:bg-brand/15 hover:shadow-[0_0_28px_-6px_rgba(139,77,255,0.7)]"
          >
            <ChevronDown className={cn("h-4 w-4 transition-transform", showAll && "rotate-180")} aria-hidden="true" />
            مشاهده همه
          </button>
          <div id="all-projects" className="menu-panel w-full max-w-sm" data-open={showAll}>
            <ul className="overflow-hidden">
              {PROJECTS.map((p, i) => (
                <li key={p.title} className="pt-2 first:pt-4">
                  <button
                    type="button"
                    tabIndex={showAll ? 0 : -1}
                    onClick={() => {
                      setIndex(i);
                      setPaused(true);
                    }}
                    className={cn(
                      "flex w-full items-center justify-between rounded-xl border px-4 py-2.5 text-start text-sm transition-colors",
                      i === index ? "border-violet bg-brand/15 text-txt" : "border-line/70 text-txt-2 hover:border-brand/70"
                    )}
                  >
                    <span>{p.title}</span>
                    <span className="text-xs text-muted">{p.category}</span>
                  </button>
                </li>
              ))}
            </ul>
          </div>
        </Reveal>

        <Reveal delay={120} className="relative">
          <div
            aria-hidden="true"
            className="pointer-events-none absolute inset-x-[8%] top-[10%] h-[70%] rounded-full bg-[radial-gradient(circle,rgba(93,43,255,0.3),transparent_65%)] blur-2xl"
          />
          <div
            className="relative mx-auto max-w-[700px]"
            onMouseEnter={() => setPaused(true)}
            onMouseLeave={() => setPaused(false)}
          >
            <div key={index} className="slide-enter">
              <img
                src={projectsImg}
                alt={`نمونه کار: ${project.title} — ${project.category}`}
                width={1024}
                height={768}
                loading="lazy"
                style={{ filter: project.filter }}
                className="media-fade h-auto w-full select-none"
                draggable={false}
              />
            </div>
            <div className="mt-1 flex flex-col items-center gap-2">
              <p className="text-xs text-muted" aria-live="polite">
                {project.title} · {project.category}
              </p>
              <div role="tablist" aria-label="انتخاب نمونه کار" className="flex items-center gap-1">
                {PROJECTS.map((p, i) => (
                  <button
                    key={p.title}
                    type="button"
                    role="tab"
                    aria-selected={i === index}
                    aria-label={`نمونه کار ${i + 1}: ${p.title}`}
                    onClick={() => {
                      setIndex(i);
                      setPaused(true);
                    }}
                    className="group flex h-6 items-center px-1"
                  >
                    <span
                      className={cn(
                        "block h-1 rounded-full transition-all duration-300",
                        i === index ? "w-8 bg-violet" : "w-5 bg-line group-hover:bg-brand/70"
                      )}
                    />
                  </button>
                ))}
              </div>
            </div>
          </div>
        </Reveal>
      </div>
    </section>
  );
}
