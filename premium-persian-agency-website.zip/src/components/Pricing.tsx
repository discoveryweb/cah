import { Check } from "lucide-react";
import { PLANS, toFa } from "../data";
import { Button, Reveal, SectionBadge } from "./ui";
import { cn } from "../utils/cn";

const ORDER_CLASS: Record<string, string> = {
  basic: "order-2 lg:order-3",
  pro: "order-3 lg:order-2",
  advanced: "order-4 lg:order-1",
};

export function PricingCard({
  plan,
  onOrder,
}: {
  plan: (typeof PLANS)[number];
  onOrder: () => void;
}) {
  const f = plan.featured;
  return (
    <div
      className={cn(
        "relative flex h-full flex-col rounded-2xl p-5 transition-all duration-300 hover:-translate-y-1",
        f
          ? "border-2 border-violet bg-gradient-to-b from-[#1a1c5c]/90 to-[#0f1340]/95 shadow-[0_0_46px_-8px_rgba(139,77,255,0.65)] lg:py-7"
          : "glass-card hover:border-violet/60"
      )}
    >
      {f && (
        <span className="absolute -top-3 right-1/2 translate-x-1/2 whitespace-nowrap rounded-full bg-gradient-to-l from-brand to-violet px-3.5 py-0.5 text-[11px] font-semibold text-white shadow-[0_6px_16px_-4px_rgba(113,60,255,0.9)]">
          پیشنهاد ویژه
        </span>
      )}
      <h3 className="text-xl font-extrabold text-txt">{plan.title}</h3>
      <p className="mt-1 text-xs text-muted">{plan.subtitle}</p>

      <p className="mt-5 flex items-baseline gap-1.5 whitespace-nowrap">
        <span className="text-[1.65rem] font-extrabold leading-none lg:text-[1.35rem] xl:text-[1.65rem] text-txt">{toFa(plan.price)}</span>
        <span className="text-xs text-txt-2">تومان</span>
      </p>

      <ul className="mt-5 space-y-2 text-[13px] text-txt-2">
        {plan.features.map((t) => (
          <li key={t} className="flex items-center gap-2">
            <Check className="h-4 w-4 shrink-0 text-violet" strokeWidth={2.4} aria-hidden="true" />
            {t}
          </li>
        ))}
      </ul>

      <div className="mt-auto pt-6">
        <Button
          onClick={onOrder}
          variant={f ? "primary" : "outline"}
          arrow={f}
          ariaLabel={`سفارش پلن ${plan.title}`}
          className="h-11 w-full border-line text-[13px] hover:border-violet"
        >
          سفارش
        </Button>
      </div>
    </div>
  );
}

export function Pricing({ onOrder }: { onOrder: (service?: string, plan?: string) => void }) {
  return (
    <section id="pricing" className="relative py-8 lg:py-12">
      <div className="mx-auto max-w-[1180px] px-5 sm:px-8">
        <div className="grid items-center gap-6 lg:grid-cols-[1fr_1fr_1fr_1.15fr] lg:gap-4">
          <Reveal className="order-1 flex flex-col items-start lg:order-4 lg:ps-6">
            <SectionBadge>پلن‌ها</SectionBadge>
            <h2 className="mt-4 text-[1.9rem] font-extrabold leading-[1.5] text-txt sm:text-[2.1rem]">
              قیمت‌های شفاف
              <br />و منصفانه
            </h2>
            <p className="mt-3 text-sm leading-[2] text-txt-2">
              با توجه به نیاز شما، بهترین گزینه را
              <br />
              انتخاب کنید.
            </p>
            <Button href="#plans" className="mt-5 h-11 px-7 text-[13px]">
              مشاهده پلن‌ها
            </Button>
          </Reveal>

          <div id="plans" className="contents">
            {PLANS.map((p, i) => (
              <Reveal key={p.id} delay={i * 90} className={cn("h-full", ORDER_CLASS[p.id], p.featured && "lg:self-stretch")}>
                <div className={cn("h-full", !p.featured && "lg:py-3")}>
                  <PricingCard plan={p} onOrder={() => onOrder(p.option, p.title)} />
                </div>
              </Reveal>
            ))}
          </div>
        </div>
        <p className="mt-6 text-center text-[11px] text-muted lg:text-start">
          قیمت‌ها نمونه و قابل تغییر هستند؛ هزینه نهایی پس از مشاوره و بررسی نیازهای پروژه اعلام می‌شود.
        </p>
      </div>
    </section>
  );
}
