import ctaImg from "../assets/cta.jpg";
import { Button, Reveal } from "./ui";

export function CtaBanner({ onOrder }: { onOrder: () => void }) {
  return (
    <section id="contact" className="relative py-6 lg:py-8">
      <div className="mx-auto max-w-[1180px] px-5 sm:px-8">
        <Reveal>
          <div className="relative overflow-hidden rounded-3xl border border-brand/50 bg-gradient-to-l from-[#2a1d8f] via-[#1a1a6e] to-[#0f1245] shadow-[0_30px_80px_-30px_rgba(93,43,255,0.7)]">
            <div
              aria-hidden="true"
              className="pointer-events-none absolute inset-y-0 left-0 w-[55%] bg-[radial-gradient(ellipse_at_20%_50%,rgba(139,77,255,0.45),transparent_60%)] sm:w-[40%]"
            />
            <img
              src={ctaImg}
              alt=""
              aria-hidden="true"
              loading="lazy"
              width={640}
              height={320}
              className="pointer-events-none absolute -left-6 top-1/2 hidden h-[140%] w-auto max-w-none -translate-y-1/2 select-none object-contain opacity-95 mix-blend-lighten sm:block"
              style={{
                WebkitMaskImage: "linear-gradient(90deg,#000 55%,transparent 100%)",
                maskImage: "linear-gradient(90deg,#000 55%,transparent 100%)",
              }}
            />
            <div className="relative flex flex-col items-center gap-5 px-6 py-8 text-center sm:py-9 lg:flex-row lg:justify-between lg:px-12">
              <Button onClick={onOrder} className="order-2 h-11 px-8 lg:order-1">
                شروع کنید
              </Button>
              <div className="order-1 lg:order-2 lg:flex-1 lg:px-6">
                <h2 className="text-xl font-extrabold text-txt sm:text-2xl">آماده‌اید سایت خود را بسازید؟</h2>
                <p className="mt-2 text-[13px] leading-[1.9] text-txt-2 sm:text-sm">
                  با ما در ارتباط باشید تا بهترین راهکار را برای کسب‌وکار شما ارائه کنیم.
                </p>
              </div>
            </div>
          </div>
        </Reveal>
      </div>
    </section>
  );
}
