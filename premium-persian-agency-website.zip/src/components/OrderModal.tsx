import { useEffect, useRef, useState, type FormEvent } from "react";
import { CheckCircle2, AlertCircle, Mail, X } from "lucide-react";
import { SERVICE_OPTIONS } from "../data";
import { cn } from "../utils/cn";

/**
 * INTEGRATION POINT
 * Set VITE_ORDER_ENDPOINT (e.g. a Formspree / custom API URL accepting JSON POST)
 * to deliver orders to your backend. Optionally set VITE_ORDER_EMAIL for the
 * mailto fallback used when no endpoint is configured.
 */
const ENDPOINT = (import.meta.env.VITE_ORDER_ENDPOINT as string | undefined) || "";
const EMAIL = (import.meta.env.VITE_ORDER_EMAIL as string | undefined) || "hello@websaz.example";

const faDigits = (s: string) =>
  s.replace(/[۰-۹]/g, (d) => String("۰۱۲۳۴۵۶۷۸۹".indexOf(d))).replace(/[٠-٩]/g, (d) => String("٠١٢٣٤٥٦٧٨٩".indexOf(d)));

type Errors = Partial<Record<"name" | "phone" | "service" | "message", string>>;
type Status = "idle" | "sending" | "success" | "error" | "draft";

export function OrderModal({
  open,
  onClose,
  initialService,
  initialPlan,
}: {
  open: boolean;
  onClose: () => void;
  initialService?: string;
  initialPlan?: string;
}) {
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [service, setService] = useState("");
  const [message, setMessage] = useState("");
  const [errors, setErrors] = useState<Errors>({});
  const [status, setStatus] = useState<Status>("idle");
  const firstRef = useRef<HTMLInputElement>(null);
  const lastFocus = useRef<HTMLElement | null>(null);

  useEffect(() => {
    if (!open) return;
    lastFocus.current = document.activeElement as HTMLElement;
    setService(initialService ?? "");
    setStatus("idle");
    setErrors({});
    document.body.style.overflow = "hidden";
    const t = window.setTimeout(() => firstRef.current?.focus(), 50);
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && onClose();
    window.addEventListener("keydown", onKey);
    return () => {
      window.clearTimeout(t);
      window.removeEventListener("keydown", onKey);
      document.body.style.overflow = "";
      lastFocus.current?.focus?.();
    };
  }, [open, initialService, onClose]);

  if (!open) return null;

  const validate = (): Errors => {
    const e: Errors = {};
    if (name.trim().length < 3) e.name = "لطفاً نام و نام خانوادگی خود را وارد کنید.";
    if (!/^(\+98|0098|98|0)?9\d{9}$/.test(faDigits(phone).replace(/[\s-]/g, "")))
      e.phone = "شماره موبایل معتبر نیست (مثال: ۰۹۱۲۱۲۳۴۵۶۷).";
    if (!service) e.service = "نوع خدمت را انتخاب کنید.";
    if (message.trim().length < 10) e.message = "توضیح پروژه را حداقل در ۱۰ نویسه بنویسید.";
    return e;
  };

  const submit = async (ev: FormEvent) => {
    ev.preventDefault();
    const e = validate();
    setErrors(e);
    if (Object.keys(e).length) return;

    const payload = {
      name: name.trim(),
      phone: faDigits(phone).replace(/[\s-]/g, ""),
      service,
      plan: initialPlan ?? null,
      message: message.trim(),
    };

    if (!ENDPOINT) {
      // No backend connected: never claim success. Offer an honest email draft instead.
      const body = `نام: ${payload.name}\nموبایل: ${payload.phone}\nخدمت: ${payload.service}${
        payload.plan ? `\nپلن: ${payload.plan}` : ""
      }\n\nتوضیحات:\n${payload.message}`;
      window.location.href = `mailto:${EMAIL}?subject=${encodeURIComponent("سفارش طراحی سایت — " + payload.service)}&body=${encodeURIComponent(body)}`;
      setStatus("draft");
      return;
    }

    setStatus("sending");
    try {
      const res = await fetch(ENDPOINT, {
        method: "POST",
        headers: { "Content-Type": "application/json", Accept: "application/json" },
        body: JSON.stringify(payload),
      });
      if (!res.ok) throw new Error(String(res.status));
      setStatus("success");
      setName("");
      setPhone("");
      setMessage("");
    } catch {
      setStatus("error");
    }
  };

  const field =
    "h-11 w-full rounded-xl border bg-ink/70 px-3.5 text-sm text-txt placeholder:text-muted transition-colors focus:border-violet focus:outline-none focus:ring-2 focus:ring-violet/30";

  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center sm:items-center sm:p-4">
      <div className="absolute inset-0 bg-[#03051a]/80 backdrop-blur-sm" onClick={onClose} aria-hidden="true" />
      <div
        role="dialog"
        aria-modal="true"
        aria-labelledby="order-title"
        className="glass-card relative max-h-[94vh] w-full max-w-lg overflow-y-auto rounded-t-3xl p-6 shadow-[0_30px_90px_-20px_rgba(93,43,255,0.6)] sm:rounded-3xl sm:p-8"
        style={{ background: "linear-gradient(180deg,#141a48,#0b1032)" }}
      >
        <button
          type="button"
          onClick={onClose}
          aria-label="بستن"
          className="absolute left-4 top-4 flex h-9 w-9 items-center justify-center rounded-full text-txt-2 hover:bg-white/10 hover:text-txt"
        >
          <X className="h-5 w-5" aria-hidden="true" />
        </button>
        <h2 id="order-title" className="text-xl font-extrabold text-txt">
          ثبت درخواست مشاوره و سفارش
        </h2>
        <p className="mt-1 text-xs leading-6 text-txt-2">
          {initialPlan ? `پلن انتخابی: ${initialPlan} — ` : ""}اطلاعات پروژه را بنویسید تا با شما تماس بگیریم.
        </p>

        {status === "success" ? (
          <div role="status" className="mt-6 flex items-start gap-3 rounded-2xl border border-emerald-400/40 bg-emerald-400/10 p-4 text-sm text-emerald-100">
            <CheckCircle2 className="mt-0.5 h-5 w-5 shrink-0" aria-hidden="true" />
            <p>درخواست شما با موفقیت ثبت شد. به‌زودی با شما تماس می‌گیریم.</p>
          </div>
        ) : (
          <form onSubmit={submit} noValidate className="mt-5 space-y-4">
            <div>
              <label htmlFor="o-name" className="mb-1.5 block text-xs font-medium text-txt-2">
                نام و نام خانوادگی <span className="text-lav">*</span>
              </label>
              <input
                id="o-name"
                ref={firstRef}
                value={name}
                onChange={(e) => setName(e.target.value)}
                autoComplete="name"
                aria-invalid={!!errors.name}
                aria-describedby={errors.name ? "e-name" : undefined}
                className={cn(field, errors.name ? "border-red-400/70" : "border-line")}
              />
              {errors.name && <p id="e-name" className="mt-1 text-xs text-red-300">{errors.name}</p>}
            </div>
            <div>
              <label htmlFor="o-phone" className="mb-1.5 block text-xs font-medium text-txt-2">
                شماره موبایل <span className="text-lav">*</span>
              </label>
              <input
                id="o-phone"
                dir="ltr"
                inputMode="tel"
                autoComplete="tel"
                placeholder="09123456789"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                aria-invalid={!!errors.phone}
                aria-describedby={errors.phone ? "e-phone" : undefined}
                className={cn(field, "text-right placeholder:text-right", errors.phone ? "border-red-400/70" : "border-line")}
              />
              {errors.phone && <p id="e-phone" className="mt-1 text-xs text-red-300">{errors.phone}</p>}
            </div>
            <div>
              <label htmlFor="o-service" className="mb-1.5 block text-xs font-medium text-txt-2">
                نوع خدمت <span className="text-lav">*</span>
              </label>
              <select
                id="o-service"
                value={service}
                onChange={(e) => setService(e.target.value)}
                aria-invalid={!!errors.service}
                className={cn(field, errors.service ? "border-red-400/70" : "border-line")}
              >
                <option value="">انتخاب کنید…</option>
                {SERVICE_OPTIONS.map((o) => (
                  <option key={o} value={o}>
                    {o}
                  </option>
                ))}
              </select>
              {errors.service && <p className="mt-1 text-xs text-red-300">{errors.service}</p>}
            </div>
            <div>
              <label htmlFor="o-msg" className="mb-1.5 block text-xs font-medium text-txt-2">
                توضیح کوتاه پروژه <span className="text-lav">*</span>
              </label>
              <textarea
                id="o-msg"
                rows={4}
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                aria-invalid={!!errors.message}
                className={cn(field, "h-auto resize-none py-2.5 leading-7", errors.message ? "border-red-400/70" : "border-line")}
              />
              {errors.message && <p className="mt-1 text-xs text-red-300">{errors.message}</p>}
            </div>

            {status === "error" && (
              <div role="alert" className="flex items-start gap-2 rounded-xl border border-red-400/40 bg-red-400/10 p-3 text-xs leading-6 text-red-100">
                <AlertCircle className="mt-0.5 h-4 w-4 shrink-0" aria-hidden="true" />
                ارسال درخواست انجام نشد. لطفاً اتصال اینترنت را بررسی کرده و دوباره تلاش کنید.
              </div>
            )}
            {status === "draft" && (
              <div role="status" className="flex items-start gap-2 rounded-xl border border-brand/50 bg-brand/10 p-3 text-xs leading-6 text-lav">
                <Mail className="mt-0.5 h-4 w-4 shrink-0" aria-hidden="true" />
                سرویس دریافت آنلاین سفارش هنوز متصل نشده است. پیش‌نویس ایمیل در برنامه ایمیل شما باز شد؛ درخواست شما فقط پس از ارسال آن ایمیل ثبت می‌شود.
              </div>
            )}

            <button
              type="submit"
              disabled={status === "sending"}
              className="btn-grad flex h-12 w-full items-center justify-center rounded-full text-sm font-semibold text-white transition-all disabled:opacity-60"
            >
              {status === "sending" ? "در حال ارسال…" : "ارسال درخواست"}
            </button>
          </form>
        )}
      </div>
    </div>
  );
}
