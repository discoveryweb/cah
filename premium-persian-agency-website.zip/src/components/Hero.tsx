import { Globe } from "lucide-react";
import heroImg from "../assets/hero.jpg";
import { Button, Reveal } from "./ui";

export function Hero({ onOrder }: { onOrder: () => void }) {
  return (
    <section id="home" className="relative">
      <div className="mx-auto grid max-w-[1180px] items-center gap-6 px-5 pb-6 pt-6 sm:px-8 lg:grid-cols-[0.92fr_1.08fr] lg:gap-4 lg:pb-8 lg:pt-10">
        {/* text — left on desktop (as in the reference), top on mobile */}
        <Reveal className="order-1 flex flex-col items-start lg:order-2 lg:items-end lg:text-left lg:ps-2 xl:ps-10">
          <span className="inline-flex items-center gap-2.5 rounded-full border border-brand/60 bg-ink-2/70 px-4 py-1.5 text-xs text-txt-2">
            طراحی سایت | برندینگ | فروشگاه آنلاین
            <span className="h-2 w-2 rounded-full bg-violet shadow-[0_0_10px_3px_rgba(139,77,255,0.8)]" aria-hidden="true" />
          </span>

          <h1 className="mt-6 text-[2.15rem] font-extrabold leading-[1.55] text-txt sm:text-[2.6rem] lg:text-[2.7rem] xl:text-[2.9rem]">
            سایت حرفه‌ای
            <br />
            برای <span className="text-grad">رشد</span> کسب‌وکار
          </h1>

          <p className="mt-5 max-w-md text-sm leading-[2] text-txt-2 sm:text-[15px]">
            طراحی سایت‌های مدرن، سریع و بهینه
            <br />
            با تمرکز بر برندینگ و تجربه کاربری عالی
          </p>

          <Button onClick={onOrder} className="mt-7 h-12 px-8">
            مشاوره و سفارش
          </Button>
        </Reveal>

        {/* illustration */}
        <Reveal delay={150} className="relative order-2 lg:order-1">
          <div
            aria-hidden="true"
            className="pointer-events-none absolute left-[8%] top-[6%] h-[75%] w-[85%] animate-drift rounded-full bg-[radial-gradient(circle,rgba(93,43,255,0.38),transparent_65%)] blur-2xl"
          />
          <div className="relative mx-auto max-w-[640px] animate-float">
            <img
              src={heroImg}
              alt="نمونه سایت مدرن روی لپ‌تاپ و گوشی هوشمند با نورپردازی بنفش"
              width={1024}
              height={768}
              fetchPriority="high"
              className="media-fade h-auto w-full select-none"
              draggable={false}
            />
            <div className="absolute bottom-[12%] left-[2%] hidden w-[32%] min-w-[130px] rotate-[-3deg] rounded-2xl border border-white/15 bg-white/[0.07] p-3 text-center shadow-[0_18px_40px_-16px_rgba(60,30,200,0.8)] backdrop-blur-md sm:block">
              <Globe className="mx-auto h-7 w-7 text-lav" strokeWidth={1.4} aria-hidden="true" />
              <p className="mt-1.5 text-[11px] leading-5 text-txt">
                سایتی که
                <br />
                فروش می‌سازد
              </p>
            </div>
          </div>
        </Reveal>
      </div>
    </section>
  );
}
