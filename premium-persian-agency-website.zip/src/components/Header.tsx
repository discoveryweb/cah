import { useEffect, useRef, useState, type FormEvent } from "react";
import { Menu, Search, X, SquarePen } from "lucide-react";
import { LogoMark } from "./ui";
import { NAV_LINKS } from "../data";
import { cn } from "../utils/cn";

const SEARCH_INDEX: { keys: string[]; id: string }[] = [
  { keys: ["نمونه", "پروژه", "کار"], id: "projects" },
  { keys: ["خدمات", "سایت", "برند", "فروشگاه", "لندینگ", "سئو"], id: "services" },
  { keys: ["قیمت", "پلن", "هزینه", "تعرفه"], id: "pricing" },
  { keys: ["نظر", "مشتری", "رضایت"], id: "testimonials" },
  { keys: ["تماس", "سفارش", "مشاوره"], id: "contact" },
];

export function Header({ onOrder }: { onOrder: () => void }) {
  const [open, setOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const [active, setActive] = useState("home");
  const [searchOpen, setSearchOpen] = useState(false);
  const [query, setQuery] = useState("");
  const [notFound, setNotFound] = useState(false);
  const searchRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    const onScroll = () => {
      setScrolled(window.scrollY > 12);
      const y = window.scrollY + 140;
      let current = "home";
      for (const l of NAV_LINKS) {
        const el = document.getElementById(l.id);
        if (el && el.offsetTop <= y) current = l.id;
      }
      if (window.innerHeight + window.scrollY >= document.documentElement.scrollHeight - 4) current = "contact";
      setActive(current);
    };
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") {
        setOpen(false);
        setSearchOpen(false);
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);

  useEffect(() => {
    if (searchOpen) searchRef.current?.focus();
  }, [searchOpen]);

  const submitSearch = (e: FormEvent) => {
    e.preventDefault();
    const q = query.trim();
    if (!q) return;
    const hit = SEARCH_INDEX.find((s) => s.keys.some((k) => q.includes(k) || k.includes(q)));
    if (hit) {
      setNotFound(false);
      setSearchOpen(false);
      setQuery("");
      document.getElementById(hit.id)?.scrollIntoView({ behavior: "smooth" });
    } else {
      setNotFound(true);
    }
  };

  return (
    <header
      className={cn(
        "sticky top-0 z-40 transition-colors duration-300",
        scrolled || open ? "bg-ink/80 backdrop-blur-xl border-b border-line/40" : "bg-transparent border-b border-transparent"
      )}
    >
      <div className="mx-auto flex h-16 max-w-[1180px] items-center justify-between gap-4 px-5 sm:px-8 lg:h-[72px]">
        <a href="#home" className="flex items-center gap-2" aria-label="وبساز — صفحه اصلی">
          <LogoMark className="h-9 w-9 drop-shadow-[0_0_14px_rgba(139,77,255,0.7)]" />
          <span className="text-[22px] font-extrabold tracking-tight text-txt">وبساز</span>
        </a>

        <nav aria-label="منوی اصلی" className="hidden lg:block">
          <ul className="flex items-center gap-7">
            {NAV_LINKS.map((l) => (
              <li key={l.id}>
                <a
                  href={l.href}
                  aria-current={active === l.id ? "page" : undefined}
                  className={cn(
                    "relative block py-2 text-[13px] transition-colors hover:text-txt",
                    active === l.id ? "text-lav" : "text-txt-2"
                  )}
                >
                  {l.label}
                  <span
                    className={cn(
                      "absolute inset-x-0 -bottom-0.5 h-0.5 rounded-full bg-gradient-to-l from-violet to-brand transition-transform duration-300",
                      active === l.id ? "scale-x-100" : "scale-x-0"
                    )}
                  />
                </a>
              </li>
            ))}
          </ul>
        </nav>

        <div className="flex items-center gap-3">
          <button
            type="button"
            onClick={onOrder}
            className="btn-grad hidden h-10 items-center gap-2 rounded-full px-5 text-xs font-semibold text-white transition-all hover:-translate-y-0.5 sm:inline-flex"
          >
            <SquarePen className="h-3.5 w-3.5" aria-hidden="true" />
            سفارش طراحی سایت
          </button>

          <div className="relative">
            <button
              type="button"
              aria-label="جستجو"
              aria-expanded={searchOpen}
              onClick={() => setSearchOpen((v) => !v)}
              className="flex h-10 w-10 items-center justify-center rounded-full text-txt-2 transition-colors hover:bg-white/5 hover:text-txt"
            >
              <Search className="h-[18px] w-[18px]" aria-hidden="true" />
            </button>
            {searchOpen && (
              <form
                onSubmit={submitSearch}
                role="search"
                className="glass-card absolute left-0 top-12 z-50 w-[min(18rem,calc(100vw-2.5rem))] rounded-2xl p-3 backdrop-blur-xl"
              >
                <label htmlFor="site-search" className="sr-only">
                  جستجو در سایت
                </label>
                <input
                  id="site-search"
                  ref={searchRef}
                  value={query}
                  onChange={(e) => {
                    setQuery(e.target.value);
                    setNotFound(false);
                  }}
                  placeholder="مثلاً: قیمت، خدمات، نمونه کار…"
                  className="h-10 w-full rounded-xl border border-line bg-ink/70 px-3 text-sm text-txt placeholder:text-muted focus:border-violet focus:outline-none"
                />
                {notFound && <p className="mt-2 text-xs text-txt-2">نتیجه‌ای پیدا نشد. عبارت دیگری را امتحان کنید.</p>}
              </form>
            )}
          </div>

          <button
            type="button"
            className="flex h-10 w-10 items-center justify-center rounded-full border border-line text-txt lg:hidden"
            aria-label={open ? "بستن منو" : "باز کردن منو"}
            aria-expanded={open}
            aria-controls="mobile-menu"
            onClick={() => setOpen((v) => !v)}
          >
            {open ? <X className="h-5 w-5" aria-hidden="true" /> : <Menu className="h-5 w-5" aria-hidden="true" />}
          </button>
        </div>
      </div>

      <div id="mobile-menu" className="menu-panel lg:hidden" data-open={open} aria-hidden={!open}>
        <div className="overflow-hidden">
          <nav aria-label="منوی موبایل" className="mx-auto max-w-[1180px] px-5 pb-5 sm:px-8">
            <ul className="glass-card flex flex-col rounded-2xl p-2">
              {NAV_LINKS.map((l) => (
                <li key={l.id}>
                  <a
                    href={l.href}
                    tabIndex={open ? 0 : -1}
                    onClick={() => setOpen(false)}
                    className={cn(
                      "flex min-h-12 items-center rounded-xl px-4 text-sm transition-colors hover:bg-white/5",
                      active === l.id ? "bg-brand/15 text-lav" : "text-txt-2"
                    )}
                  >
                    {l.label}
                  </a>
                </li>
              ))}
              <li className="p-2 sm:hidden">
                <button
                  type="button"
                  tabIndex={open ? 0 : -1}
                  onClick={() => {
                    setOpen(false);
                    onOrder();
                  }}
                  className="btn-grad flex h-11 w-full items-center justify-center gap-2 rounded-full text-sm font-semibold text-white"
                >
                  <SquarePen className="h-4 w-4" aria-hidden="true" />
                  سفارش طراحی سایت
                </button>
              </li>
            </ul>
          </nav>
        </div>
      </div>
    </header>
  );
}
