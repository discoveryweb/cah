export function loadServerEnv(): void;
